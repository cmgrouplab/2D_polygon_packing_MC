


using namespace std;

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "const.h"
#include "Geometry.2d.h"
#include "Polygon.h"
//#include "Cells.2d.h"
#include "Packing.h"


void Packing::Rescale(double relax_ratio) //if packing containing overlapping pairs, rescale the packing
{
  for(int i=0; i<SD; i++)
    for(int j=0; j<SD; j++)
      Lambda[i][j] = relax_ratio*Lambda[i][j];
}

void Packing::Check_Iconfig(double temp_option, double relax_ratio)
{
  //cout<<"In Check_Iconfig 1"<<endl;

  int temp_flag = GlobalOverlapCheck(1);
  
  if(temp_flag == 1)
    {
  
      if(temp_option == 0)
	{
	  while(GlobalOverlapCheck(1)==1)
	    {
	      //printf("The Initial Configuration Contains Overlapping Pairs!\n");
	      Rescale(relax_ratio);
	      //exit(1);
	    }
	}
      else if(temp_option == 1)
	{ 
	  exit(1);
	}
    }

}

Packing::Packing(char* temp_name)
{
  FILE* fp;

  if((fp=fopen("Iconfig.txt","r"))==NULL)
    {
      printf("Cannot open file Iconfig.txt to initialize Packing!\n");
      exit(1);
    }
  else //read the initial configuration...
    {
      double val;
      fscanf(fp, "%d", &N); // read in the number of particles...
      
      fscanf(fp, "%lf", &d0); // read in the length...
      //for monodisperse packings, d0 is the edge length of the shape
      //for polydisperse or random shapes, should be the maximal length for all shapes.

      Lambda = new double*[SD];
      for(int i=0; i<SD; i++)
	Lambda[i] = new double[SD];
      
      for(int i=0; i<SD; i++) // read in the lattice vectors...
	for(int j=0; j<SD; j++)
	  {
	    fscanf(fp, "%lf", &val);
	    Lambda[j][i] = val;
	  }

        //now initalize the variables

      CenterE = new double*[N];
      CenterL = new double*[N];

      PackPoly = new Polygon[N]; //new [] cannot call constructors with parameters
      
      for(int i=0; i<N; i++)
	{
	  CenterE[i] = new double[SD];	  
	  CenterL[i] = new double[SD];

	  PackPoly[i].PolyConstr(temp_name);
	  
	}
      
      for(int i=0; i<N; i++) // read the posistions of the center and the vertex
	{
	  //read in the center of mass
	  fscanf(fp, "%lf", &val); CenterL[i][0] = val; 
	  if(CenterL[i][0]>=1.0) CenterL[i][0] = CenterL[i][0]-1.0;
	  else if(CenterL[i][0]<0) CenterL[i][0] = CenterL[i][0]+1.0;
	  fscanf(fp, "%lf", &val); CenterL[i][1] = val;
	  if(CenterL[i][1]>=1.0) CenterL[i][1] = CenterL[i][1]-1.0;
	  else if(CenterL[i][1]<0) CenterL[i][1] = CenterL[i][1]+1.0;
        
	   
	  //read in vertex with O = 0; and to make sure, shift the vertices again for each particle
	  
	  for(int v=0; v<PackPoly[i].n_vertex; v++)
	    for(int j=0; j<SD; j++)
	      {
		fscanf(fp, "%lf", &val);
		PackPoly[i].Vertex[v][j] = val;
	      }

	 
	  PackPoly[i].ShiftVert(); //shift vertices to make the centroid at orgin

	  //PackPoly[i].GetNormal_All(); //get the face normals
	  //no need to compute all the face normals, only compute those used for overlap check

	  PackPoly[i].GetCentDist(); //get d_cf and d_cv
	  //cout<<"d_cv["<<i<<"] = "<<PackPoly[i].d_cv[0]<<endl;

	  

	  //get the maximum characteristic length of the particle... 
	  //double temp_d = 2*GetMax(PackPoly[i].d_cv, PackPoly[i].n_vertex);
	  //if(temp_d>d0) d0 = temp_d;
	  //cout<<"d0 = "<<d0<<endl;

	}//finishing loop over all particles
      
      
      
      fclose(fp);
    }

  
  //now we compute the total volume of all particles, which is a constant of the packing

  GetVParticle();

}

void Packing::GetGlobalPosition()
{
  //compute the global posistions of the center of mass
  for(int n=0; n<N; n++)
    {
      for(int i=0; i<SD; i++)
	{
	  
	  CenterE[n][i] = Lambda[i][0]*CenterL[n][0]+Lambda[i][1]*CenterL[n][1];
	}
      
    }
}


double Packing::MinDis(double CenterLm[SD], double CenterLn[SD], double temp_disE[SD], int indexI, int indexJ)
{
  //find the minimal distance between the centers of two polyhedra in Ecludean space...
  //by checking all the images of Polygon[m], while keeping Polygon[n] in the central box
  //record the index of the box which Tetrah[m] is in...
  //the order (m,n) is important, especially when getting the NNL.... 
  
  double tempLd[SD];

  tempLd[0] = (CenterLm[0]-CenterLn[0])+indexI;
  tempLd[1] = (CenterLm[1]-CenterLn[1])+indexJ;
  
  for(int q=0; q<SD; q++)
    temp_disE[q] = 0;
  
  for(int q=0; q<SD; q++)
    for(int h=0; h<SD; h++)
      temp_disE[q] += Lambda[q][h]*tempLd[h];
  
  double dist = temp_disE[0]*temp_disE[0]+temp_disE[1]*temp_disE[1]; 

  //printf("Dist = %f\n", dist);

  return sqrt(dist); //this is center-to-center distance...
}


double Packing::MinDisII(int m, int n, double temp_disE[SD], int &indexI, int &indexJ)
{
  double tempLd[SD];
  double tempEd[SD];
  double min_dist = 10000000000.0;
  double temp_dist;

  for(int i=-1; i<=1; i++)
    for(int j=-1; j<=1; j++)
      {

	tempLd[0] = (CenterL[m][0]-CenterL[n][0])+i;
	tempLd[1] = (CenterL[m][1]-CenterL[n][1])+j;
	
	
	for(int q=0; q<SD; q++)
	  tempEd[q] = 0;
	
	for(int q=0; q<SD; q++)
	  for(int h=0; h<SD; h++)
	    tempEd[q] += Lambda[q][h]*tempLd[h];
	
	temp_dist = tempEd[0]*tempEd[0]+tempEd[1]*tempEd[1]; 
	
	if(temp_dist < min_dist)
	  {
	    min_dist = temp_dist;
	    
	    for(int q=0; q<SD; q++)
	      temp_disE[q] = tempEd[q];
	    
	    indexI = i; indexJ = j; 
	  }
      }
  
  return sqrt(min_dist);
  
}


double Packing::GetMin(double Arr[], int Size)
{
  double temp_min = 1000000000.0;

  for(int i=0; i<Size; i++)
    {
      if(Arr[i]<temp_min) temp_min = Arr[i];
    }

  return temp_min;
}

double Packing::GetMax(double Arr[], int Size)
{
  double temp_max = -1000000000.0;

  for(int i=0; i<Size; i++)
    {
      if(Arr[i]>temp_max) temp_max = Arr[i];
    }

  return temp_max;
}


int Packing::LineOverlap(double LmPA[SD], double LmPB[SD], double LnPA[SD], double LnPB[SD])
{
  double vect1[SD];
  double vect2[SD];

  double pA; //the inner product....
  double pB;
  
  double vect3[SD];
  double vect4[SD];

  double Delta = 0.00000000001;
  //this is a relxation parameter to deal with perfectly aligning edges pointing from one to another

  //first, check if the normal of Lm works...
  for(int i=0; i<SD; i++)
    {
      vect1[i] = LmPA[i] - LmPB[i];
      vect3[i] = LnPA[i] - LmPA[i];
      vect4[i] = LnPB[i] - LmPA[i];
    }

  Comput.Normalize(vect1);
  
  //this is the perpendicular direction...
  vect2[0] = -vect1[1]; vect2[1] = vect1[0];
  
  //get inner product
  pA = Comput.GetInnerProduct(vect3, vect2);
  pB = Comput.GetInnerProduct(vect4, vect2);

  //both A and B on the same side of Lm
  if((pA*pB)>-Delta)
    return 0;


  //if the above is not true, check normal of Ln...
   for(int i=0; i<SD; i++)
    {
      vect1[i] = LnPA[i] - LnPB[i];
      vect3[i] = LmPA[i] - LnPA[i];
      vect4[i] = LmPB[i] - LnPA[i];
    }

  Comput.Normalize(vect1);
  
  //this is the perpendicular direction...
  vect2[0] = -vect1[1]; vect2[1] = vect1[0];
  
  //get inner product
  pA = Comput.GetInnerProduct(vect3, vect2);
  pB = Comput.GetInnerProduct(vect4, vect2);

  //both A and B on the same side of Lm
  if((pA*pB)>=-Delta)
    return 0;

  //if none of the above works, meaning the line segment overlaps...
  return 1;
}



//try to generalize this to check all shapes
//make sure the particle do not check its old position for overlap

int Packing::CheckOverlap(Polygon &Pm, Polygon &Pn, double CenterLm[SD], double CenterLn[SD], int indexI, int indexJ)
{
  double temp_VdisE[SD]; //the relative and Ecludean separation distance... the vector from n to m
  
  //first get the center-to-center distance of the particles...
  double temp_dis = MinDis(CenterLm, CenterLn, temp_VdisE, indexI, indexJ);
  //recall n is fixed in the central box, the images of m are checked...

  //the mininmal and maximal possible separations
  double d_cvmax = (GetMax(Pm.d_cv, Pm.n_vertex)+GetMax(Pn.d_cv, Pn.n_vertex));
  //double d_cfmin = (GetMin(Pm.d_cf, Pm.n_face)+GetMin(Pn.d_cf, Pn.n_face));

  double Delta = 0.0000001; //a relax variable for floating point number comparision
  
  if(temp_dis>d_cvmax || temp_dis<Delta) return 0; //greater than largest possible separation, definitely not overlapping or checking the particle itself, i.e., m = n
  //else if(temp_dis<d_cfmin &&  temp_dis>=Delta) return 1; //smaller than the smallest possible separation, definitely overlapping


  //if in the intermediate distance, need to check with the separation axis theorem
  //need to do the complete check if overlapping: the most inefficient cases...


  //*******************************************************************
  int overlap_flag = 0;

  //shift Pm to the absolute position, Pn is at origin
  double Pm_vertex[Pm.n_vertex][SD];
  for(int i=0; i<Pm.n_vertex; i++)
    for(int j=0; j<SD; j++)
      Pm_vertex[i][j] = Pm.Vertex[i][j] + temp_VdisE[j];


  //check any pairs of edges of the two particles...
  for(int i=0; i<Pn.n_edge; i++)
    for(int j=0; j<Pm.n_edge; j++)
      {
	if(LineOverlap(Pm_vertex[Pm.Edge[j][0]], Pm_vertex[Pm.Edge[j][1]], Pn.Vertex[Pn.Edge[i][0]], Pn.Vertex[Pn.Edge[i][1]]) == 1)
	  {
	    overlap_flag = 1;
	    break;
	  }
	
      }
  //if the double loop is finished, this means that none of edge pairs is overlapping
  
  //if we get here, then the M and N overlap...
  
  return overlap_flag;

}

//this can be used for small packing checks...
int Packing::GlobalOverlapCheck(int a)
{
  int overlap_flag = 0;
  
  for(int m=0; m<N; m++)
    for(int n=m; n<N; n++)
      {
	//cout<<"In GOC "<<m<<" "<<n<<endl;
	
	for(int i=-1; i<=1; i++)
	  for(int j=-1; j<=1; j++)
	    {
	      
	      
	      if(CheckOverlap(PackPoly[n], PackPoly[m], CenterL[n], CenterL[m], i, j) == 1) 
		{
		  printf("Polygon %d <%d, %d> and Polygon %d overlap!\n", n, i, j, m);
		  //PrintOverlapPair(n, m);
		  overlap_flag = 1;
		}
	    }
      }
  
  
  return overlap_flag;
}

int Packing::GlobalOverlapCheck(double a)
{
  int overlap_flag = 0;
  
  for(int m=0; m<N; m++)
    for(int n=m; n<N; n++)
      {
	//cout<<"In GOC "<<m<<" "<<n<<endl;
	
	for(int i=-1; i<=1; i++)
	  for(int j=-1; j<=1; j++)
	    {
	      
	      
	      if(CheckOverlap(PackPoly[n], PackPoly[m], CenterL[n], CenterL[m], i, j) == 1) 
		{
		  //printf("Polygon %d <%d, %d> and Polygon %d overlap!\n", n, i, j, m);
		  //PrintOverlapPair(n, m);
		  overlap_flag = 1;
		}
	    }
      }
  
  
  return overlap_flag;
}

//assuming the cell list is already there...
int Packing::GlobalOverlapCheck(Cells &BoxCell)
{
  int overlap_flag = 0; //assuming no overlapping...
  
  for(int m=0; m<N; m++)
    {
      
      int temp_indI = (int)floor(CenterL[m][0]*BoxCell.LXcell);
      int temp_indJ = (int)floor(CenterL[m][1]*BoxCell.LYcell);
     
      
      //cout<<" Neighbor of ["<<m<<"] = ( ";
      
      for(int i=-1; i<=1; i++)
	for(int j=-1; j<=1; j++)
	  {
	    int indexI = 0;
	    int indexJ = 0;
	    
	    
	    int tempI = temp_indI + i;
	    if(tempI>=BoxCell.LXcell) 
	      {
		tempI = tempI-BoxCell.LXcell;
		indexI = 1;
	      }
	    else if(tempI<0) 
	      {
		tempI = tempI+BoxCell.LXcell;
		indexI = -1;
	      }
	    int tempJ = temp_indJ + j;
	    if(tempJ>=BoxCell.LYcell) 
	      {
		tempJ = tempJ-BoxCell.LYcell;
		indexJ = 1;
	      }
	    else if(tempJ<0) 
	      {
		tempJ = tempJ+BoxCell.LYcell; 
		indexJ = -1;
	      }
	   
	    
	    
	    int cell_index = BoxCell.LXcell*tempJ + tempI;
	      
	    node* pt = BoxCell.CellList[cell_index];
	    
	    while(pt!=NULL)
	      {
		int temp_P = pt->index_poly;
		
		//cout<<temp_P<<"<"<<indexI<<","<<indexJ<<","<<indexK<<">"<<"\t";
		
		if(CheckOverlap(PackPoly[temp_P], PackPoly[m], CenterL[temp_P], CenterL[m], indexI, indexJ)==1) //the particles overlap
		  {
		    overlap_flag = 1;
		    
		    printf("Polygon %d and Polygon %d overlap!\n", temp_P, m);
		    //PrintOverlapPair(temp_P, m);		    
		    
		    return overlap_flag; //indicating overlapping...
		  }
		
		pt = pt->next;
	      }
	  }//end of loop over all neighboring cells...
      
      
      //cout<<")"<<endl;
      
    }//end of loop over all particles...
  
  
  
  //if we reach here, then no overlap...

  return overlap_flag;

}

void Packing::GetVParticle()
{
  VParticle = 0.0;

  for(int i=0; i<N; i++)
    {      
      VParticle += PackPoly[i].GetVol();      
    }
}

double Packing::GetDensity()
{
  double VLambda;
  VLambda = (Lambda[0][0]*Lambda[1][1] - Lambda[1][0]*Lambda[0][1]);
 
  return VParticle/VLambda;

}

void Packing::PrintOverlapPair(int m, int n)
{
  FILE* fp = fopen("OverlapPair.txt","w");
  
  fprintf(fp, "%d\n", 2);
  fprintf(fp, "%.12f\n", d0);
  
  for(int i=0; i<SD; i++)
    {
      for(int j=0; j<SD; j++)
	fprintf(fp, "%.12f\t", Lambda[j][i]);
      
      fprintf(fp, "\n");
    }
  fprintf(fp, "\n");
   
  fprintf(fp, "%.12f\t%.12f\n", CenterL[m][0], CenterL[m][1]);
  
  for(int j=0; j<PackPoly[m].n_vertex; j++)
    fprintf(fp, "%.12f\t%.12f\n", PackPoly[m].Vertex[j][0], PackPoly[m].Vertex[j][1]);
  
  fprintf(fp, "\n");
  
  fprintf(fp, "%.12f\t%.12f\n", CenterL[n][0], CenterL[n][1]);
  
  for(int j=0; j<PackPoly[n].n_vertex; j++)
    fprintf(fp, "%.12f\t%.12f\n", PackPoly[n].Vertex[j][0], PackPoly[n].Vertex[j][1]);
  
  fprintf(fp, "\n");
 
  fclose(fp);
}


void Packing::PrintPacking()
{
  FILE* fp = fopen("Fconfig.txt","w");
  
  fprintf(fp, "%d\n", N);
  fprintf(fp, "%.12f\n", d0);
  
  for(int i=0; i<SD; i++)
    {
      for(int j=0; j<SD; j++)
	fprintf(fp, "%.12f\t", Lambda[j][i]);
      
      fprintf(fp, "\n");
    }
  fprintf(fp, "\n");
 
  for(int i=0; i<N; i++)
    {
      fprintf(fp, "%.12f\t%.12f\n", CenterL[i][0], CenterL[i][1]);
      
      for(int j=0; j<PackPoly[i].n_vertex; j++)
	fprintf(fp, "%.12f\t%.12f\n", PackPoly[i].Vertex[j][0], PackPoly[i].Vertex[j][1]);
      
      fprintf(fp, "\n");
    }
  
  fclose(fp);
}


void Packing::PrintDensity()
{
  FILE* fp;
  if((fp=fopen("rho.txt","a"))==NULL)
    {
      fp = fopen("rho.txt","w");
      fprintf(fp, "%f\n", GetDensity());
      fclose(fp);
    }
  else
    {
      fp=fopen("rho.txt","a");
      fprintf(fp, "%f\n", GetDensity());
      fclose(fp);
    }
}

void Packing::PrintDensity(double rho_t)
{
  FILE* fp;
  if((fp=fopen("rho.txt","a"))==NULL)
    {
      fp = fopen("rho.txt","w");
      fprintf(fp, "%f\n", rho_t);
      fclose(fp);
    }
  else
    {
      fp=fopen("rho.txt","a");
      fprintf(fp, "%f\n", rho_t);
      fclose(fp);
    }
}
