//A class that defines a generic polyhedron shape
//necessary functions are defined here


class Polygon{

 public:

  char* poly_name; //the name of the polyhedron
  int n_vertex; //number of vertices
  int n_edge; //num of edges
  
  double** Vertex; //vertex coordinates
  int** Edge; //edge configuration
  
  double* d_cv; //centroid to vertex distance

  Geometry Comput; //for computing the products
  
  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Polygon(); //for "new []", which can not call constructor with parameters
  Polygon(char*); //initialize polyhedron based on given name
  //NOTE: the order of the vertex is crucial!!!!
  void PolyConstr(char*); //for "new []" which cannot use constructors with parameters
  //exactly the same as Polygon(char*)
  void ShiftVert(); //shift the vert to make the centroid at 0;

  void GetCentDist(); //compute d_cf and d_cv
  void CopyPoly(Polygon &); //copy the later to the former
  Polygon& operator = (Polygon &); //reload operator
  double GetVol(); //comput the vol of the particle
  ~Polygon(); //desturcturor
};


