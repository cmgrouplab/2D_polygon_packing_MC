
using namespace std;

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include "const.h" //specify spatial dimension
#include "Geometry.2d.h"
#include "Polygon.h"

Polygon::Polygon()
{
  //this is the default constructor...
}


//IMPORTANT NOTE: for the codes specific for each shape, the vertex order is arbitary since
//                the face configuration is computed by search for nearest neighbors of each vertex
//                Here, we specify the face configuration, therefore vertex order is CRUCIAL!!!!!
Polygon::Polygon(char* temp_name)
{ 
  if(strcmp(temp_name,"user")==0 || strcmp(temp_name,"U")==0)
    {
      //for general shapes, need to play with the face_type

      cout<<" This USER SPECIFIED polygon shape: "<<endl;
      cout<<" Need to provide basic geometric parameters, edge-config in required format"<<endl;
      //cout<<" Still under construction..."<<endl;
      //exit(1);

      poly_name = "user";

      ifstream fin;
      fin.open("shape_param.txt");
      if(!fin)
	{
	  cout<<"Can not open file shape_param.txt! Re-check! "<<endl;
	  exit(1);
	}
      
      char dummy[100]; //for polyhedron name
      fin>>dummy; cout<<dummy<<endl;

      fin>>n_vertex; //cout<<"n_vertex = "<<n_vertex<<endl;
      fin>>n_edge; //cout<<"n_edge = "<<n_edge<<endl;
    
      
      Vertex = new double*[n_vertex];
      for(int i=0; i<n_vertex; i++)
	Vertex[i] = new double[SD];
      
      Edge = new int*[n_edge];
      for(int i=0; i<n_edge; i++)
	Edge[i] = new int[2];
      
      d_cv = new double[n_vertex];

      //now we read in the edge pairs
      for(int i=0; i<n_edge; i++)
	{
	  fin>>Edge[i][0]; fin>>Edge[i][1];
	  //cout<<"Edge_"<<i<<" = ("<<Edge[i][0]<<","<<Edge[i][1]<<")"<<endl;
	}

      fin.close();
      
    }
  else
    {
      cout<<" Polygon "<<temp_name<<" has not been programmed yet!"<<endl;
      exit(1);
    }
  //here just prepare the data type, the values to be read in later
}



//exactly the same as Polygon(char*)
//for "new []" which cannot call constructor with parameters
void Polygon::PolyConstr(char* temp_name)
{
  if(strcmp(temp_name,"user")==0 || strcmp(temp_name,"U")==0)
    {
      //for general shapes, need to play with the face_type
      
      //cout<<" This USER SPECIFIED polyhedron shape: "<<endl;
      //cout<<" Need to provide basic geometric parameters, edge-config, face-config in required format"<<endl;
      //cout<<" Still under construction..."<<endl;
      //exit(1);

      poly_name = "user";

      ifstream fin;
      fin.open("shape_param.txt");
      if(!fin)
	{
	  cout<<"Can not open file shape_param.txt! Re-check! "<<endl;
	  exit(1);
	}
      
      char dummy[100]; //for polyhedron name
      fin>>dummy; cout<<dummy<<endl;

      fin>>n_vertex; //cout<<"n_vertex = "<<n_vertex<<endl;
      fin>>n_edge; //cout<<"n_edge = "<<n_edge<<endl;
    
      
      Vertex = new double*[n_vertex];
      for(int i=0; i<n_vertex; i++)
	Vertex[i] = new double[SD];
      
      Edge = new int*[n_edge];
      for(int i=0; i<n_edge; i++)
	Edge[i] = new int[2];
      
      d_cv = new double[n_vertex];

      //now we read in the edge pairs
      for(int i=0; i<n_edge; i++)
	{
	  fin>>Edge[i][0]; fin>>Edge[i][1];
	  //cout<<"Edge_"<<i<<" = ("<<Edge[i][0]<<","<<Edge[i][1]<<")"<<endl;
	}

      fin.close();

      //cout<<"Here!"<<endl;
      
    }
  else
    {
      cout<<" Polygon "<<temp_name<<" has not been programmed yet!"<<endl;
      exit(1);
    }

  //here just prepare the data type, the values to be read in later
}



void Polygon::ShiftVert()
{
  double Centroid[SD];
  for(int i=0; i<SD; i++)
    Centroid[i] = 0.0;

  for(int i=0; i<n_vertex; i++)
    for(int j=0; j<SD; j++)
      Centroid[j] += Vertex[i][j];

  for(int i=0; i<n_vertex; i++)
    for(int j=0; j<SD; j++)
      Vertex[i][j] = Vertex[i][j] - Centroid[j]/(double)n_vertex;
}



void Polygon::GetCentDist()
{ 
  ShiftVert();
  
  //now get the center2vertex distance
  for(int i=0; i<n_vertex; i++)
    d_cv[i] = Comput.GetLength(Vertex[i]);
  
} 

//this only works for the same type of polyhedron, i.e., copy a tetrah from a terah
// one can not copy a tetrah from an octahedron
// thus, only the coordinate data need to be copied, others e.g., n_vertex etc are initialized when poly type is declared
void Polygon::CopyPoly(Polygon &B)
{
  /*
  n_vertex = B.n_vertex;
  n_edge = B.n_edge;
  n_face = B.n_face;
  n_fs = B.n_fs; //not really need this one, even for complicated shapes...
  max_face_vert = B.max_face_vert;

  for(int i=0; i<n_fs; i++)
    {
      face_num_fspecie[i] = B.face_num_fspecie[i];
      vert_num_fspecie[i] = B.vert_num_fspecie[i];
    }
  */

  for(int i=0; i<n_vertex; i++)
    for(int k=0; k<SD; k++)
      Vertex[i][k] = B.Vertex[i][k];
  
  /*
  for(int i=0; i<n_edge; i++)
    for(int k=0; k<2; k++)
      Edge[i][k] = B.Edge[i][k];
  */
  
  
  for(int i=0; i<n_vertex; i++)
    d_cv[i] = B.d_cv[i];
        
}


//reload operator =
Polygon& Polygon::operator = (Polygon &B)
{
  CopyPoly(B);

  return *this;
}


//for all complicated shapes, divide the shape into pyrimad with bases being the faces of the polyhedron
double Polygon::GetVol()
{
  
  if(strcmp(poly_name,"user")==0 || strcmp(poly_name,"U")==0)
    {
      double vect1[SD], vect2[SD], vect3[SD], vect4[SD];
      double vol = 0.0;
      double temp_cos;

      ShiftVert();
      
      for(int i=0; i<n_edge; i++)
	{
	  for(int k=0; k<SD; k++)
	    {
	      vect1[k] = Vertex[Edge[i][0]][k];
	      vect2[k] = Vertex[Edge[i][1]][k];
	    }

	  temp_cos = Comput.GetInnerProduct(vect1, vect2)/(Comput.GetLength(vect1)*Comput.GetLength(vect2));

	  vol += 0.5*sqrt(1.0-temp_cos*temp_cos)*Comput.GetLength(vect1)*Comput.GetLength(vect2);
	  
	}
      //cout<<"vol_cube = "<<vol<<endl;
      return vol;
    }
  else
    {
      cout<<"The volume for the shape is not programmed! Provide number denstiy only!"<<endl;
      return 1.0;
    }
}



//free all the memory space when the object is destroyed
Polygon::~Polygon()
{
  for(int i=0; i<n_vertex; i++)
    delete [] Vertex[i];
  delete [] Vertex;

  for(int i=0; i<n_edge; i++)
    delete [] Edge[i];
  delete [] Edge;

  delete [] d_cv;

  //cout<<"Destructor for Polygon is called!"<<endl;
}
